<template>
    <div>
        <el-empty description="页面去火星了~">
            <el-button type="primary"
             @click="$router.push('/')">返回首页
            </el-button>
        </el-empty>
    </div>
</template>

<script>


    export default {
   
}
</script>

<style scoped>

</style>