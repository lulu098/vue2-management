<template>
    <div>
        这是人事考勤页
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="less" scoped>

</style>